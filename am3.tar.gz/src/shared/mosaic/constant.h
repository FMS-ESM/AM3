#define RADIUS        (6371000.)
#define STRING        255
